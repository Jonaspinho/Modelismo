/* Leitura do catalogo.csv (separador vírgula; aspas duplas para campos com vírgula) */
function parseCSV(t){
  const rows=[];let row=[],f="",q=false;
  for(let i=0;i<t.length;i++){
    const c=t[i];
    if(q){ if(c==='"'){ if(t[i+1]==='"'){f+='"';i++} else q=false } else f+=c }
    else if(c==='"') q=true;
    else if(c===","){row.push(f);f=""}
    else if(c==="\n"||c==="\r"){ if(c==="\r"&&t[i+1]==="\n")i++; row.push(f);f="";rows.push(row);row=[] }
    else f+=c;
  }
  if(f!==""||row.length){row.push(f);rows.push(row)}
  return rows;
}
async function carregarCatalogo(){
  const r=await fetch("catalogo.csv",{cache:"no-cache"});
  if(!r.ok) throw new Error("catalogo.csv não encontrado");
  const t=(await r.text()).replace(/^\uFEFF/,"");
  const [h,...rs]=parseCSV(t);
  return rs.filter(r=>r.length>1).map(r=>Object.fromEntries(h.map((k,i)=>[k.trim(),(r[i]||"").trim()])));
}
/* Capa em iframe: imagem (jpg/png/svg/webp) vira srcdoc; PDF abre direto sem barras */
function criarIframeCapa(url,titulo){
  const f=document.createElement("iframe");
  f.title="Capa: "+titulo;f.tabIndex=-1;f.loading="lazy";
  if(/\.pdf($|[?#])/i.test(url)) f.src=url+(url.includes("#")?"":"#toolbar=0&navpanes=0&scrollbar=0&view=Fit");
  else{
    const u=url.replace(/&/g,"&amp;").replace(/"/g,"&quot;");
    f.srcdoc='<style>html,body{margin:0;height:100%}img{width:100%;height:100%;object-fit:cover;display:block}</style><img src="'+u+'" alt="">';
  }
  return f;
}
